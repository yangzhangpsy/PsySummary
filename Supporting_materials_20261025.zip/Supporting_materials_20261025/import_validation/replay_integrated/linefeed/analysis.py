from aggregateData import AggregateData
aggData = AggregateData()
fileList = ['../../import_cases/quoted.csv']
aggData.readDatFiles(fileList, True, 'utf-8', ',')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed.psydata")

fileList = ['../../import_cases/custom.txt']
aggData.readDatFiles(fileList, True, 'utf-8', '\\|\\|')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed.psydata")

fileList = ['../../import_cases/tabs.dat']
aggData.readDatFiles(fileList, True, 'utf-8', '\t')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed.psydata")

fileList = ['../../import_cases/no_header.txt']
aggData.readDatFiles(fileList, False, 'utf-8', '(?:\\s)+')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed.psydata")

fileList = ['../../import_cases/legacy_gbk.txt']
aggData.readDatFiles(fileList, True, 'gbk', ',')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed.psydata")

fileList = ['../../import_cases/utf8_bom.csv']
aggData.readDatFiles(fileList, True, 'utf-8', ',')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed.psydata")

fileList = ['../../import_cases/quoted_tab.dat']
aggData.readDatFiles(fileList, True, 'utf-8', '\t')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed.psydata")

fileList = ['../../import_cases/missing_ids.csv']
aggData.readDatFiles(fileList, True, 'utf-8', ',')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed.psydata")

fileList = ['../../import_cases/blank_text.csv']
aggData.readDatFiles(fileList, True, 'utf-8', ',')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed.psydata")

fileList = ['../../import_cases/linefeed.csv']
aggData.readDatFiles(fileList, True, 'utf-8', ',')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed.psydata")
