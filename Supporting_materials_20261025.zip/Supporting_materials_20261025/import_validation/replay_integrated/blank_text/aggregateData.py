import csv
import os
import re
from dataPreparation import (
    read_delimited_file, has_estimated_filter,
    grouped_filter_estimates, numeric_filter_mask, is_range_expression, parse_checklist_values, prepare_summary_frame, safe_mode, split_filter_rule, read_psydata, write_psydata,
)
from expression import prepare_variable
from operator import lt, le, ge, gt

import mat73

import numpy as np
import pandas as pd
from scipy.io import loadmat
from scipy.optimize import minimize

from rtDist import gamma_estimate_x, shifted_gamma_estimate_x, wald_estimate_x, ex_wald_estimate_x, \
    ex_gaussian_estimate_x, inverse_gaussian_estimate_x, shifted_inverse_gaussian_estimate_x, \
    weibull_estimate_x, shifted_weibull_estimate_x, log_normal_estimate_x, shifted_log_normal_estimate_x, \
    shift_wald_estimate_x, CDF_pooling_main, FIT_DIAGNOSTIC_NAMES, fit_rt_distribution_values
from cognitiveModels import fit_cognitive_model
from cognitiveModelSpec import (
    COGNITIVE_MODEL_NAMES, cognitive_model_reference_text, split_target, model_result_parameters, validate_model_data,
)


CONDITION_WISE_FILTER_REFERENCE = (
    'André, Q. (2022). Outlier exclusion procedures must be blind to the researcher\'s hypothesis. '
    'Journal of Experimental Psychology: General, 151(1), 213–223. '
    'https://doi.org/10.1037/xge0001069'
)
SOURCE_FILE_COLUMN = 'source_file'


def mapDataFrameElements(dataFrame, function):
    """Apply a scalar function with both current and legacy pandas versions."""
    mapper = getattr(dataFrame, 'map', None)
    if mapper is None:
        mapper = dataFrame.applymap
    return mapper(function)


def addSourceFileColumn(
        data_frames,
        file_paths,
        preferred_name=SOURCE_FILE_COLUMN,
        existing_source_columns=(),
):
    """Add a source filename column only when imported data do not already contain one."""
    frames = list(data_frames)
    paths = list(file_paths)
    if len(frames) != len(paths):
        raise ValueError('Each imported data frame must have one matching source file path.')
    recognized_columns = (preferred_name,) + tuple(existing_source_columns)
    for frame, file_path in zip(frames, paths):
        if not any(column in frame.columns for column in recognized_columns):
            frame[preferred_name] = os.path.basename(os.fsdecode(file_path))
    return frames, preferred_name


def warnConditionWiseFiltering(row_var_list, column_var_list, data_frame, rule_list):
    """Print a warning when active filters are combined with multiple observed data cells."""
    grouping_variables = list(dict.fromkeys(list(row_var_list) + list(column_var_list)))
    if not grouping_variables or not has_estimated_filter(rule_list):
        return 0
    combination_count = int(data_frame[grouping_variables].drop_duplicates().shape[0])
    if combination_count > 1:
        grouping_label = ' × '.join(grouping_variables)
        print(
            'WARNING: Group-estimated filtering: The current Rows × Columns settings define '
            f'{combination_count} observed data cells ({grouping_label}). '
            'SD, MAD, Shifting Z, or Pooling CDF criteria are estimated within the configured groups. '
            'If these groups separate experimental conditions, this can exaggerate between-condition differences. '
            'Consider computing exclusion criteria '
            'blind to the experimental condition (for example, within participant but collapsed across '
            f'conditions). Reference: {CONDITION_WISE_FILTER_REFERENCE}'
        )
    return combination_count


def isCompareCond(expression: str):
    return is_range_expression(expression)


def executeDataFilter(dataFrame, variableName: str, compareType: str, value):
    if isinstance(value, (pd.DataFrame, pd.Series)):
        values = value.values
    else:
        values = value

    compare_functions = {
        '<': lt,
        '<=': le,
        '>': gt,
        '>=': ge
    }

    compare_operation = compare_functions.get(compareType)
    filtered_index = compare_operation(dataFrame[[variableName]].values, values)
    return filtered_index


def contains_empty_list(x):
    return any(hasattr(item, '__len__') and len(item) == 0 for item in x)


def getStandardError(x):
    """Calculate sample standard error using only non-missing observations."""
    return pd.Series(x).sem(skipna=True, ddof=1)


def getValueInExpression(expression: str):
    numbers_str_list = re.findall(r"-?\d+\.\d+|-?\d+", expression)

    nz = int(numbers_str_list[0]) if '.' not in numbers_str_list[0] else float(numbers_str_list[0])
    return nz


def sumTable2DataFrame(row_var_list: list, column_var_list: list, sumTable, dataFrame, getShiftingZ: bool = False):
    variableNamesAll = row_var_list.copy()
    variableNamesAll.extend(column_var_list)

    output_df = pd.DataFrame(columns=['values'], index=dataFrame.index)

    if row_var_list:
        for rowIndex in sumTable.index:
            if isinstance(sumTable.index, pd.MultiIndex):
                row_value_list = list(rowIndex)
            else:
                row_value_list = [rowIndex]

            if column_var_list:
                for colIndex in sumTable.columns:
                    category_Value_list = row_value_list.copy()

                    if isinstance(sumTable.columns, pd.MultiIndex):
                        category_Value_list.extend(list(colIndex))
                    else:
                        category_Value_list.extend([colIndex])

                    logical_compare = dataFrame[variableNamesAll] == category_Value_list
                    output_df.loc[logical_compare.all(axis=1), 'values'] = sumTable.loc[rowIndex, colIndex]
            else:
                category_Value_list = row_value_list.copy()
                logical_compare = dataFrame[variableNamesAll] == category_Value_list
                output_df.loc[logical_compare.all(axis=1), 'values'] = sumTable.loc[rowIndex, sumTable.columns[0]]
    else:
        for colIndex in sumTable.columns:
            if isinstance(sumTable.columns, pd.MultiIndex):
                category_Value_list = list(colIndex)
            else:
                category_Value_list = [colIndex]

            logical_compare = dataFrame[variableNamesAll] == category_Value_list
            output_df.loc[logical_compare.all(axis=1), 'values'] = sumTable.loc[sumTable.index[0], colIndex]

    if getShiftingZ:
        output_df['values'] = output_df['values'].apply(singleShiftZs)

    return output_df


def doFilterOutData(row_var_list: list, column_var_list: list, expression: str, dataFrame, columnName: str):
    """Reuse the same range engine as GUI and PsyHSSM preparation."""
    method = ('Shifting Z' if 'Shifting Z' in expression else 'MAD' if 'MAD' in expression
              else 'SDs' if 'SD' in expression else 'Raw value')
    value = 0. if method == 'Shifting Z' else getValueInExpression(expression)
    return numeric_filter_mask(dataFrame, columnName, expression[:2].strip(), method, value,
                               row_var_list + column_var_list, singleShiftZs).reshape(-1, 1)


def filterDataFunc(row_var_list, column_var_list, dataFrame, ruleList, omegaValues=None):
    if omegaValues is None:
        omegaValues = [-1 for _ in ruleList]

    tmp_data_frame = dataFrame.copy()

    for index, rule in enumerate(ruleList):
        variable_name, conditional_expression = split_filter_rule(rule)
        # 区分range规则和checklist规则
        if isCompareCond(conditional_expression):
            if not pd.api.types.is_numeric_dtype(tmp_data_frame[variable_name]):
                tmp_data_frame[variable_name] = pd.to_numeric(tmp_data_frame[variable_name], errors='coerce')

            # range规则
            if 'and' in conditional_expression:
                expression_1, expression_2 = conditional_expression.split('and')

                filter_index1 = doFilterOutData(row_var_list, column_var_list, expression_1, tmp_data_frame,
                                                variable_name)
                filter_index2 = doFilterOutData(row_var_list, column_var_list, expression_2, tmp_data_frame,
                                                variable_name)

                tmp_data_frame = tmp_data_frame[np.logical_and(filter_index1, filter_index2)]
            elif 'or' in conditional_expression:
                expression_1, expression_2 = conditional_expression.split('or')

                filter_index1 = doFilterOutData(row_var_list, column_var_list, expression_1, tmp_data_frame,
                                                variable_name)
                filter_index2 = doFilterOutData(row_var_list, column_var_list, expression_2, tmp_data_frame,
                                                variable_name)

                tmp_data_frame = tmp_data_frame[np.logical_or(filter_index1, filter_index2)]
            else:
                filter_index1 = doFilterOutData(row_var_list, column_var_list, conditional_expression,
                                                tmp_data_frame, variable_name)
                tmp_data_frame = tmp_data_frame[filter_index1]

        elif 'Pooling CDF' == conditional_expression:

            cutoff = validate_cdf_cutoff(omegaValues[index], allow_abort=True)
            if cutoff != -1:
                tmp_data_frame = CDF_pooling_main(tmp_data_frame, row_var_list, column_var_list, variable_name)

                # Match the GUI: retain CDF values at or below the slow-tail cutoff.
                filtered_df = tmp_data_frame[tmp_data_frame[f"{variable_name}_cdf"] <= cutoff]
                tmp_data_frame = filtered_df
            else:
                print("Aborted CDF pooling; no changes will be made to the data.")
        else:
            # checkList rules
            data = parse_checklist_values(conditional_expression)
            filtered_df = tmp_data_frame[tmp_data_frame[variable_name].isin(data)]
            tmp_data_frame = filtered_df

    return tmp_data_frame


# Shared cutoff likelihood and estimator; no independent GUI/replay algorithm.
from poolingCDF import outlier_mode_lnlike, fit_outlier_model, validate_cdf_cutoff


def groupby_to_pivot_tables(grouped_result, index_var=None, columns_var=None):
    """
    Convert grouped results into multiple pivot-table-like DataFrames.

    Parameters:
    - grouped_result: Result of groupby operation
    - index_var: Variable name for pivot table rows (optional)
    - columns_var: Variable name for pivot table columns (optional)

    Returns: Dictionary of DataFrames
    """
    # Convert grouped result to DataFrame
    # Handle both Series and DataFrame inputs
    if isinstance(grouped_result, pd.Series):
        df = grouped_result.apply(pd.Series)
    else:
        df = grouped_result

        # Reset index to prepare for pivot operation
    df_reset = df.reset_index()

    # Extract original grouping variable names
    group_vars = list(df_reset.columns[:len(df.index.names)])

    # Dictionary to store pivot tables for each column
    pivot_tables = []

    # Iterate through columns (excluding grouping columns)
    for col in df.columns:
        # Handle different pivoting scenarios
        if index_var and columns_var:
            # Both index and columns variables specified
            # Create standard two-dimensional pivot table
            pivot_table = df_reset.pivot(
                index=index_var,
                columns=columns_var,
                values=col
            )
        elif columns_var and not index_var:
            # Only columns variable specified
            # Use pivot_table to get column-wise aggregation
            pivot_table = df_reset.pivot_table(
                index=None,
                columns=columns_var,
                values=col,
                aggfunc='first', observed=True
            )
        elif index_var and not columns_var:
            # Only index variable specified
            # Use pivot_table to get index-wise aggregation
            pivot_table = df_reset.pivot_table(
                index=index_var,
                columns=None,
                values=col,
                aggfunc='first', observed=True
            )
        else:
            # Return original column data
            pivot_table = df_reset[[col]].copy()

            # Store pivot table in results dictionary
        pivot_tables.append(pivot_table)

    return pivot_tables


def singleShiftZs(count):
    """Delegate to the shared, replayable sample-size coefficient table."""
    from dataPreparation import shifting_z_coefficient
    return shifting_z_coefficient(count)


def flattenValue(value):
    if isinstance(value, list) and len(value) > 0 and isinstance(value[0], list):  # 如果是列表（二维数组）
        return value[0]
    else:  # 如果是整数值或其他类型的值
        if len(value) == 0:
            return None
        if len(value[0]) == 0:
            return value[0]
        if isinstance(value[0], str):
            return value[0]
        if len(value[0]) > 1:
            return ','.join(map(str, value[0]))
        return value[0][0]  # 直接返回该值


def flattenValueMat73(value):
    if isinstance(value, (np.bool_, bool)):
        return float(value)

    elif isinstance(value, np.ndarray):
        if value.size == 0:
            return None
        elif value.size == 1:
            return value.item()
        elif value.ndim == 1 and not isinstance(value[0], str):
            return -np.sum(value)
        return value[0]

    elif isinstance(value, (str, list)):
        # Handle list case efficiently
        return value[0] if isinstance(value, list) and len(value) > 0 else value
    return value


def readDatFile(file_path, containsHeader=True, encodingFormat='utf-8', delimiter=r'\s'):
    """Use the GUI parser and propagate invalid full-file imports instead of accepting partial data."""
    return read_delimited_file(file_path, containsHeader, encodingFormat, delimiter)


class AggregateData(object):
    def __init__(self):
        super().__init__()

        self.data = pd.DataFrame()
        self.resultList = []
        self.fitMethods = ['Gamma (k, θ)',
                           'Shifted Gamma (k, θ, shift)',
                           'Weibull (k, θ)',
                           'Shifted Weibull (k, θ, shift)',
                           'LogNormal (k, θ)',
                           'Shifted LogNormal (k, θ, shift)',
                           'Wald (m, a)',
                           'Ex-Wald (m, a, τ)',
                           'Shifted Wald (m, a, shift)',
                           'Ex-Gaussian (μ, σ, τ)',
                           'Inv-Gaussian (μ, λ)',
                           'Shifted Inv-Gaussian (μ, λ, shift)']
        self.cognitiveFitMethods = list(COGNITIVE_MODEL_NAMES)

        self.DISTRIBUTION_MAP = {
            'Gamma (k, θ)': (['shape (k)', 'scale (θ)'], gamma_estimate_x),
            'Shifted Gamma (k, θ, shift)': (
                ['shape (k)', 'scale (θ)', 'shift'], shifted_gamma_estimate_x),
            'Wald (m, a)': (['mean rate (m)', 'response threshold (a)'], wald_estimate_x),
            'Ex-Wald (m, a, τ)': (['mean rate (m)', 'response threshold (a)', 'τ'], ex_wald_estimate_x),
            'Shifted Wald (m, a, shift)': (['mean rate (m)', 'response threshold (a)', 'shift'], shift_wald_estimate_x),
            'Ex-Gaussian (μ, σ, τ)': (['mu (μ)', 'sigma (σ)', 'tau (τ)'], ex_gaussian_estimate_x),
            'Inv-Gaussian (μ, λ)': (['mu (μ)', 'lambda (λ)'], inverse_gaussian_estimate_x),
            'Shifted Inv-Gaussian (μ, λ, shift)': (
            ['mu (μ)', 'lambda (λ)', 'shift'], shifted_inverse_gaussian_estimate_x),
            'Weibull (k, θ)': (['shape (k)', 'scale (θ)'], weibull_estimate_x),
            'Shifted Weibull (k, θ, shift)': (
                ['shape (k)', 'scale (θ)', 'shift'], shifted_weibull_estimate_x),
            'LogNormal (k, θ)': (['shape (k)', 'scale (θ)'], log_normal_estimate_x),
            'Shifted LogNormal (k, θ, shift)': (
                ['shape (k)', 'scale (θ)', 'shift'], shifted_log_normal_estimate_x)}

    def savePsyData(self, file_path):
        write_psydata(self.data, file_path)

    def readPsyDataFiles(self, files: list):
        dfs = []
        for file in files:
            df = read_psydata(file)

            dfs.append(df)

        self.data = pd.concat(dfs, ignore_index=True)

    def readDatFiles(self, fileList, containsHeader=True, encodingFormat='utf-8', delimiter=r'\s'):
        all_dfs = []
        loaded_files = []

        for file in fileList:
            df = readDatFile(file, containsHeader, encodingFormat, delimiter)

            if df is not None:
                all_dfs.append(df)
                loaded_files.append(file)

        if all_dfs:
            all_dfs, _source_column = addSourceFileColumn(all_dfs, loaded_files)
            self.data = pd.concat(all_dfs, ignore_index=True)
        else:
            self.data = pd.DataFrame()

    def readMatlabFiles(self, files, appendDataModel=False):
        # Pre-allocate a list to store DataFrames for better efficiency
        data_frames = []
        loaded_files = []

        for file in files:
            mat_data = loadmat(file)
            variable = mat_data.get('allResults_APL')

            # Get column names from the first row: need to be confirmed
            columnList = [str(row.flat[0]) for line in variable[0] for row in line]

            # Convert to DataFrame, skipping the first row which contains column names
            df = pd.DataFrame(variable[1:], columns=columnList)
            # Apply the flatten function to all DataFrame elements
            df = mapDataFrameElements(df, flattenValue)

            # Append DataFrame to list
            data_frames.append(df)
            loaded_files.append(file)

        data_frames, _source_column = addSourceFileColumn(
            data_frames, loaded_files, existing_source_columns=('filename',))
        if appendDataModel:
            data_frames.insert(0, self.data)

            # Concatenate all DataFrames at once for efficiency
        self.data = pd.concat(data_frames, ignore_index=True)

    def readMatlabFiles73(self, files, appendDataModel=False):
        # Pre-allocate a list to store DataFrames for better efficiency
        data_frames = []
        loaded_files = []

        for file in files:
            mat_dat = mat73.loadmat(file)
            variable = mat_dat.get('allResults_APL', None)

            df = pd.DataFrame(variable[1:], columns=variable[0])
            df = mapDataFrameElements(df, flattenValueMat73)

            # Append DataFrame to list
            data_frames.append(df)
            loaded_files.append(file)
            # Concatenate all DataFrames at once for efficiency
        data_frames, _source_column = addSourceFileColumn(
            data_frames, loaded_files, existing_source_columns=('filename',))
        if appendDataModel:
            data_frames.insert(0, self.data)
        self.data = pd.concat(data_frames, ignore_index=True)

    def calculateVariable(self, target_variable_name, calculate_expression, allow_nonfinite=False):
        """Create a validated column, requiring acknowledgement of non-finite results."""
        name, column, _source, warning = prepare_variable(
            target_variable_name, calculate_expression, self.data)
        if warning and not allow_nonfinite:
            raise ValueError(warning + ' Use allow_nonfinite=True only after reviewing these values.')
        self.data[name] = column

    def filterData(self, row_vars, col_vars, ruleList, omegaValues=None):
        if omegaValues is None:
            omegaValues = [-1 for _ in ruleList]

        tmpDataFrame = filterDataFunc(row_vars, col_vars, self.data, ruleList, omegaValues)
        return tmpDataFrame

    def summaryData(self, row_vars, col_vars, ruleList, target_vars, omegaValues):
        if omegaValues is None:
            omegaValues = [-1 for _ in ruleList]

        self.resultList = []
        warnConditionWiseFiltering(row_vars, col_vars, self.data, ruleList)

        # Match the GUI: filter raw values before preparing each individual target.
        filteredFrame = filterDataFunc(row_vars, col_vars, self.data, ruleList, omegaValues)

        result_frame_var_names = []

        for target_var in target_vars:
            target_var_name, operation, specification = split_target(target_var)
            tmpDataFrame = prepare_summary_frame(filteredFrame, target_var_name, operation)

            result = None

            # tmpDataFrame[target_var_name] = pd.to_numeric(tmpDataFrame[target_var_name], errors='coerce')

            if operation == 'Mean':
                if len(row_vars) == 0 and len(col_vars) == 0:
                    result = tmpDataFrame[target_var_name].mean(skipna=True)
                else:
                    result = pd.pivot_table(tmpDataFrame, index=row_vars, columns=col_vars, values=target_var_name,
                                            observed=True)
            elif operation == 'Median':
                if len(row_vars) == 0 and len(col_vars) == 0:
                    result = tmpDataFrame[target_var_name].median(skipna=True)
                else:
                    result = pd.pivot_table(tmpDataFrame, index=row_vars, columns=col_vars, values=target_var_name,
                                            aggfunc='median', observed=True)
            elif operation == 'Mode':
                if len(row_vars) == 0 and len(col_vars) == 0:
                    result = safe_mode(tmpDataFrame[target_var_name])
                else:
                    result = pd.pivot_table(tmpDataFrame, index=row_vars, columns=col_vars, values=target_var_name,
                                            aggfunc=safe_mode, observed=True)
            elif operation == 'Count':
                if len(row_vars) == 0 and len(col_vars) == 0:
                    result = tmpDataFrame[target_var_name].count()
                else:
                    result = pd.pivot_table(tmpDataFrame, index=row_vars, columns=col_vars, values=target_var_name,
                                            aggfunc='count', observed=True)
            elif operation == 'Standard Deviation':
                if len(row_vars) == 0 and len(col_vars) == 0:
                    result = tmpDataFrame[target_var_name].std(skipna=True, ddof=1)
                else:
                    result = pd.pivot_table(tmpDataFrame, index=row_vars, columns=col_vars, values=target_var_name,
                                            aggfunc='std', observed=True)
            elif operation == 'Max':
                if len(row_vars) == 0 and len(col_vars) == 0:
                    result = tmpDataFrame[target_var_name].max(skipna=True)
                else:
                    result = pd.pivot_table(tmpDataFrame, index=row_vars, columns=col_vars, values=target_var_name,
                                            aggfunc='max', observed=True)
            elif operation == 'Min':
                if len(row_vars) == 0 and len(col_vars) == 0:
                    result = tmpDataFrame[target_var_name].min(skipna=True)
                else:
                    result = pd.pivot_table(tmpDataFrame, index=row_vars, columns=col_vars, values=target_var_name,
                                            aggfunc='min', observed=True)
            elif operation == 'Variance':
                if len(row_vars) == 0 and len(col_vars) == 0:
                    result = tmpDataFrame[target_var_name].var(skipna=True, ddof=1)
                else:
                    result = pd.pivot_table(tmpDataFrame, index=row_vars, columns=col_vars, values=target_var_name,
                                            aggfunc='var', observed=True)
            elif operation == 'Standard Error':
                if len(row_vars) == 0 and len(col_vars) == 0:
                    result = getStandardError(tmpDataFrame[target_var_name])
                else:
                    result = pd.pivot_table(tmpDataFrame, index=row_vars, columns=col_vars, values=target_var_name,
                                            aggfunc=getStandardError, observed=True)
            elif operation in self.fitMethods:
                group_vars = row_vars + col_vars
                parameter_names, _estimate_func = self.DISTRIBUTION_MAP[operation]
                estimate_func = lambda values: fit_rt_distribution_values(values, operation, log_diagnostics=True)

                if 'Wald' in operation:
                    print(f"Start to fit the data dist via {operation}...")
                    print(
                        f"See detailed info in Heathcote, (2004), Behavior Research Methods, Instruments & Computers, 36(4): 678-694 ...")
                else:
                    print(f"Start to fit the data dist via {operation}...")
                # Perform estimation (with or without grouping)
                if group_vars:
                    # Grouped estimation
                    grouped_result = tmpDataFrame.groupby(group_vars, observed=True)[target_var_name].apply(estimate_func)
                else:
                    # Single estimation
                    grouped_result = pd.Series({'result': estimate_func(tmpDataFrame[target_var_name])})

                result = groupby_to_pivot_tables(grouped_result, row_vars, col_vars)

                output_names = parameter_names + FIT_DIAGNOSTIC_NAMES
                target_var = [f"{target_var_name}@{operation} {item}" for item in output_names]
            elif operation in self.cognitiveFitMethods:
                if not specification:
                    raise ValueError(
                        f'{target_var_name}@{operation} has no saved model settings.')
                print(cognitive_model_reference_text(operation))
                group_vars = row_vars + col_vars
                validate_model_data(specification, tmpDataFrame, group_vars)

                def fit_model_group(group_frame):
                    fit = fit_cognitive_model(group_frame, specification, validate=False)
                    diagnostics = [
                        fit['n_valid'], 'Yes' if fit['converged'] else 'No',
                        str(fit['response_counts'])]
                    if specification.get('accuracy_variable'):
                        diagnostics.append(fit['accuracy_rate'])
                    diagnostics.extend([fit['log_likelihood'], fit['aic'], fit['bic']])
                    return np.asarray(list(fit['parameters']) + diagnostics, dtype=object)

                if group_vars:
                    grouped_values = {
                        group_key: fit_model_group(group_frame)
                        for group_key, group_frame in tmpDataFrame.groupby(
                            group_vars, dropna=False, sort=False, observed=True)
                    }
                    grouped_result = pd.Series(grouped_values)
                    grouped_result.index.names = group_vars
                else:
                    grouped_result = pd.Series({'result': fit_model_group(tmpDataFrame)})
                result = groupby_to_pivot_tables(grouped_result, row_vars, col_vars)
                parameter_names = [
                    f"{parameter['name']} ({parameter['mode'].capitalize()})"
                    for parameter in model_result_parameters(specification)
                ]
                diagnostic_names = [
                    'N valid', 'Converged', 'Response counts', 'Log-likelihood', 'AIC', 'BIC']
                if specification.get('accuracy_variable'):
                    diagnostic_names.insert(3, 'Accuracy rate')
                target_var = [
                    f'{target_var_name}@{operation} {name}'
                    for name in parameter_names + diagnostic_names
                ]

            if isinstance(target_var, list):
                result_frame_var_names.extend(target_var)
            else:
                result_frame_var_names.append(target_var)

            pd.set_option('display.float_format', lambda x: '%.10f' % x)

            if result is not None:
                if isinstance(result, list):
                    self.resultList.extend(result)
                else:
                    self.resultList.append(result)

        # print out rules and results info in command window
        print('filter rules:')
        print('========================')
        for rule in ruleList:
            print(rule)

        print('========================')

        print('results:')
        print('========================')

        for result in self.resultList:
            print(result)
