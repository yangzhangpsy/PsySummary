from aggregateData import AggregateData
aggData = AggregateData()
fileList = ['../../import_cases/quoted.csv']
aggData.readDatFiles(fileList, True, 'utf-8', ',')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed.psydata")
