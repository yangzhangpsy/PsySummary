from aggregateData import AggregateData
aggData = AggregateData()
fileList = ['../inputs/M_formal_1_2_1.mat', '../inputs/M_formal_2_1_1.mat', '../inputs/M_formal_3_2_1.mat', '../inputs/M_formal_4_1_1.mat', '../inputs/M_formal_5_2_1.mat', '../inputs/M_formal_6_1_1.mat']
aggData.readMatlabFiles(fileList, False)
aggData.data.rename(columns={'target_1.rt': 'target.rt'}, inplace=True)
aggData.data.rename(columns={'target_1.resp': 'target.resp'}, inplace=True)
aggData.data.rename(columns={'target_1.acc': 'target.acc'}, inplace=True)
aggData.data.rename(columns={'trialsLoop_1_SOA': 'SOA'}, inplace=True)
aggData.calculateVariable('log_RT', "np.log(self.data['target.rt'])")
cdfPoolingOmegas = [-1, -1]
rowVariables = ['num', 'name']
colVariables = ['SOA']
ruleList = ['target.acc:Checklist [1.0]', 'target.rt: > 0.1 and < 1.5']
targetVariables = ['target.rt@Mean']
aggData.summaryData(rowVariables, colVariables, ruleList, targetVariables, cdfPoolingOmegas)
rowVariables = ['num', 'name']
colVariables = ['SOA']
ruleList = ['target.acc:Checklist [1.0]', 'target.rt: > 0.1 and < 1.5']
cdfPoolingOmegas = [-1, -1]
filteredDataFrame = aggData.filterData(rowVariables, colVariables, ruleList, cdfPoolingOmegas)
filteredDataFrame.to_csv('../main_filtered.csv', index=False, header=True)
rowVariables = ['num', 'name']
colVariables = ['SOA']
ruleList = ['target.acc:Checklist [1.0]', 'target.rt: > 0.1 and < 1.5']
cdfPoolingOmegas = [-1, -1]
filteredDataFrame = aggData.filterData(rowVariables, colVariables, ruleList, cdfPoolingOmegas)
from dataPreparation import write_psydata
write_psydata(filteredDataFrame, '../main_filtered.psydata')
cdfPoolingOmegas = [-1, -1]
rowVariables = ['num', 'name']
colVariables = ['SOA']
ruleList = ['target.acc:Checklist [1.0]', 'target.rt: > 0.1 and < 1.0']
targetVariables = ['target.rt@Mean']
aggData.summaryData(rowVariables, colVariables, ruleList, targetVariables, cdfPoolingOmegas)
rowVariables = ['num', 'name']
colVariables = ['SOA']
ruleList = ['target.acc:Checklist [1.0]', 'target.rt: > 0.1 and < 1.0']
cdfPoolingOmegas = [-1, -1]
filteredDataFrame = aggData.filterData(rowVariables, colVariables, ruleList, cdfPoolingOmegas)
filteredDataFrame.to_csv('../sensitivity_filtered.csv', index=False, header=True)
rowVariables = ['num', 'name']
colVariables = ['SOA']
ruleList = ['target.acc:Checklist [1.0]', 'target.rt: > 0.1 and < 1.0']
cdfPoolingOmegas = [-1, -1]
filteredDataFrame = aggData.filterData(rowVariables, colVariables, ruleList, cdfPoolingOmegas)
from dataPreparation import write_psydata
write_psydata(filteredDataFrame, '../sensitivity_filtered.psydata')
from dataPreparation import write_psydata
write_psydata(aggData.data, "replayed_source.psydata")
for label, upper in [("main", 1.5), ("sensitivity", 1.0)]:
    rules = ["target.acc:Checklist [1.0]", f"target.rt: > 0.1 and < {upper}"]
    aggData.summaryData(["num", "name"], ["SOA"], rules, ["target.rt@Mean"], [-1, -1])
    aggData.resultList[0].to_csv(f"{label}_replayed_means.csv")
