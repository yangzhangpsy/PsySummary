# Tutorial Data and Workflow

## Supplied data

The six original MAT files contain 1,728 rows from six participants. `inputs/demo_renamed.psydata` contains the same imported data after the four variable renamings below. A trial with missing RT/response and very short RTs is retained in the input rather than silently repaired.

| Input name | Tutorial name | Meaning documented by the supplied materials |
| --- | --- | --- |
| target_1.rt | target.rt | Reaction time in seconds |
| target_1.resp | target.resp | Observed response code; the two recorded categories are 5 and 6 |
| target_1.acc | target.acc | Binary accuracy, 0 incorrect and 1 correct |
| trialsLoop_1_SOA | SOA | Stimulus onset asynchrony in milliseconds |

`num` and `name` identify the same six participants. Num is stored as text in the original import. SOA levels are 150, 350, 550, 850, 1150, and 1450 ms. The supplied materials do not establish the task instructions, physical meaning of response codes 5/6, or the precise events defining SOA. These details require an author-supplied description; no task narrative is inferred from filenames.

## Main and sensitivity analyses

Load the six MAT files, apply the four renamings, and create log_RT using the natural logarithm of target.rt if reproducing the transformation demonstration.

- Rows: num and name; Columns: SOA; Data: target.rt@Mean.
- Main: target.acc equals 1 and 0.1 < target.rt < 1.5 s; 1,642 retained, 86 excluded.
- Sensitivity: identical settings except upper RT bound 1.0 s; 1,636 retained, 92 excluded.
- Both configurations start from the same 1,728-row input. The narrower upper bound illustrates sensitivity to slow responses, not an optimal or preregistered rule.

The .psysum files save settings, not raw data or the import/renaming history. Load the corresponding data and variable names before reopening a setup. Counts and means are in the main/sensitivity CSV files; retained trial-level data are supplied in both CSV and typed .psydata.

The main preview identity is num=5, name=yp, SOA=1150 ms: 48 before, 2 excluded, 46 retained. Existing main and sensitivity screenshots select different cells and must not be presented as a matched-cell comparison without recapture.

## Optional CDF example

The CDF example starts from finite positive RTs and groups by participant across SOAs, with Columns empty. It contains 1,727 eligible CDF values; omega=0.999 retains 1,725. Values at or below omega are retained; values above it are excluded. Fifty trials per group is a numerical safeguard, not a reliability guarantee. The tutorial's small sample illustrates controls, not validated individual contaminant labels.

## Cognitive-model examples

Begin with the original trial-level data, remove the correct-only accuracy filter, and retain the accuracy variable. Do not fit correct/error models to a previously exported correct-only dataset. Models use seconds for target.rt. The Ratcliff GUI starting point is relative zr = z/a.

## Running the exported script

The safest full check is `python -B verification/verify_replays.py` from the package root; it works on a temporary copy. To rerun the tutorial manually, first copy this package to a working location, change into tutorial/script_replay, then run `python -B analysis.py`. The script regenerates the retained exports and summaries in that working copy.
