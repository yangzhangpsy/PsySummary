PREPROCESSING VALIDATION

This directory contains five dataset-specific validation examples. Each folder provides the available input data, settings, scripts, or numerical comparisons for the indicated procedure.

1. Lin et al. (2020): fixed-criterion SD filtering
   Folder: Lin et al, Cognition, nSDs
   Files: cogData.mat; lin et al., 2020.xlsx.
   The comparison uses correct responses, a 100-ms lower RT cutoff, and an upper cutoff of the condition-specific mean plus 2.5 SD. The spreadsheet documents the reference and PsySummary summaries. No saved .psysum setup is supplied.

2. Zhang et al. (2021): Shifting Z
   Folder: Zhang et al, JEPG, ShiftingZ
   Files: JEPG_Exp1.mat; JEPG_Exp1.psydata; JEPG_Exp1.psysum; Zhang et al, 2021.xlsx.
   The supplied settings and comparison document accuracy and eye-movement eligibility, the lower RT cutoff, and Shifting Z filtering for Experiment 1.

3. Hedge et al. (2018): MAD filtering
   Folder: Hedge et al, BRM, MAD
   Files: HedgeetalReliabilityStudy1.csv; study_session1_Flanker_data.psydata; Filter.psysum; Hedge et al., 2018.xlsx.
   The comparison concerns Session 1 of the flanker task, using correct responses, the lower RT cutoff, and the stated MAD criterion. The spreadsheet contains the reference and PsySummary summaries.

4. Routliers: MAD-based outlier detection
   Folder: Routliers, MAD
   Files: anxietyData.dat; test.psydata; filters.psysum; getOutliers.R; getOutliers.py; aggregateData.py; anxiety_outliers.txt; anxiety_outliers_psysummary.txt.
   These files compare R/Routliers and PsySummary identification of extreme anxiety-index values in the Attacks dataset. This is a numerical filtering benchmark, not an RT-specific dataset. Compare the two outlier listings. The folder README gives working-directory-independent entry points that require a new output path and do not overwrite the supplied results.

5. Richards et al. (2021): group-wise SD filtering and median summaries
   Folder: Richards_2021
   Input: Richards_etal_rawdata.csv.
   Results: results/richards_comparison.csv; results/retained_trial_indices.json; results/richards_run.json.
   Script: scripts/verify_richards_preprocessing.py.
   Lift and movement RTs are filtered separately within each participant group using mean +/- 2.5 sample SD. Participant-by-position medians are summarized and compared with the reported precision. Input RTs are seconds; the comparison reports milliseconds. IQR and touch-precision outcomes are outside the reproduced-result claim.

USING THE MATERIALS

Load the appropriate input before applying its saved setup; variable names must match. Comparison spreadsheets and result files identify the supported numerical checks. The Richards script provides --help and uses the numerical modules in ../tutorial/script_replay by default; select a separate output directory when reproducing results.

For methodological details and complete bibliographic references, see Supplementary Validation S1 and the manuscript. Numerical agreement for these specified calculations does not establish that a filtering rule is optimal for a different study.
