"""Reproduce Richards et al. group-wise RT filtering with production PsySummary."""

import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd


def run(source, output, root):
    """Save independent phase exclusions and participant-by-object RT summaries."""
    sys.path.insert(0, str(root))
    code = root / 'app/menubar/psyData'
    sys.path.insert(0, str(code if code.exists() else root))
    from aggregateData import filterDataFunc
    data = pd.read_csv(source)
    data.columns = data.columns.str.strip()
    assert len(data) == 3840
    expected = {'YOUNG': (22, 416, 179, 2.7, 0.3), 'OLD': (21, 517, 284, 2.1, 0.7),
                'VCI': (21, 570, 368, 1.8, 1.8)}
    rows = []
    retained = {}
    for phase in ('liftRT', 'moveRT'):
        # Apply each phase's two bounds to the same unfiltered input, as in the paper.
        filtered = filterDataFunc(['DataSet'], [], data, [f'{phase}: > 2.5SD and < 2.5SD'])
        if isinstance(filtered, tuple):
            filtered = filtered[0]
        retained[phase] = filtered.index.tolist()
        for group, targets in expected.items():
            original = data[data.DataSet == group]
            current = filtered[filtered.DataSet == group]
            participants = current.PPT.nunique()
            medians = current.groupby(['PPT', 'ObjectID'])[phase].median()
            mean_ms = medians.groupby('PPT').mean().mean() * 1000
            # IQR is exploratory here: the source paper does not specify a percentile convention.
            iqr = current.groupby(['PPT', 'ObjectID'])[phase].agg(lambda x: x.quantile(.75) - x.quantile(.25))
            iqr_ms = iqr.groupby('PPT').mean().mean() * 1000
            excluded_pct = (len(original) - len(current)) / len(original) * 100
            target_ms = targets[1 if phase == 'liftRT' else 2]
            target_pct = targets[3 if phase == 'liftRT' else 4]
            assert participants == targets[0]
            assert round(mean_ms) == target_ms, (phase, group, mean_ms, target_ms)
            assert round(excluded_pct, 1) == target_pct, (phase, group, excluded_pct, target_pct)
            rows.append({'group': group, 'phase': phase, 'participants': participants,
                         'n_input': len(original), 'n_retained': len(current),
                         'excluded_percent': excluded_pct, 'published_excluded_percent': target_pct,
                         'mean_participant_position_median_ms': mean_ms, 'published_median_ms': target_ms,
                         'exploratory_linear_percentile_IQR_ms': iqr_ms, 'matched_reported_precision': True})
    output.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output / 'richards_comparison.csv', index=False)
    (output / 'retained_trial_indices.json').write_text(json.dumps(retained, indent=2), encoding='utf-8')
    (output / 'richards_run.json').write_text(json.dumps({
        'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'n_rows': len(data), 'units': 'Input seconds; reported RT summaries milliseconds',
        'sd_definition': 'Sample SD, pandas ddof=1; per DataSet, separately for each phase',
        'source_code': 'app/menubar/psyData/aggregateData.py:filterDataFunc',
        'precision_analysis': 'Not reproduced; requires intersection of the two phase masks',
        'IQR_analysis': 'Exploratory linear percentile IQR does not reproduce all published IQR values; no full-pipeline equivalence is claimed',
        'provenance': 'Author-supplied local CSV; paper links OSF https://osf.io/fztbu/; byte identity with OSF not independently checked',
        'results': rows}, ensure_ascii=False, indent=2), encoding='utf-8')
    print(pd.DataFrame(rows).to_string(index=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--root', type=Path,
                        default=Path(__file__).resolve().parents[2] / 'tutorial/script_replay')
    args = parser.parse_args()
    run(args.source, args.output, args.root)
