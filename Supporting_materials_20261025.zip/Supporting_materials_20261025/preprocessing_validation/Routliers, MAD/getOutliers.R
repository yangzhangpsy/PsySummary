# Reproduce the Routliers MAD comparison without a preloaded workspace.
arguments <- commandArgs(trailingOnly = TRUE)
if (identical(arguments, "--help")) {
  cat("Usage: Rscript getOutliers.R --output /path/to/new_outliers.csv\n",
      "Requires the Routliers package. Supplied reference results are never overwritten.\n", sep = "")
  quit(status = 0)
}
if (length(arguments) != 2L || arguments[[1L]] != "--output") {
  stop("Specify --output followed by a new CSV/text output path.", call. = FALSE)
}
output <- path.expand(arguments[[2L]])
if (file.exists(output)) {
  stop("Choose a new output file; existing data and reference results must not be overwritten.", call. = FALSE)
}
if (!requireNamespace("Routliers", quietly = TRUE)) {
  stop("The Routliers package is required. Install it with install.packages('Routliers').", call. = FALSE)
}
dataset <- new.env(parent = baseenv())
utils::data("Attacks", package = "Routliers", envir = dataset)
columns <- paste0("hsc", seq_len(10L))
anxiety <- rowMeans(dataset$Attacks[, columns])
result <- Routliers::outliers_mad(x = anxiety)
dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)
utils::write.csv(result$outliers, output, row.names = FALSE)
cat(sprintf("Exported %d outlier values to %s\n", length(result$outliers), output))
