"""Export the saved Routliers example's MAD outliers to a separate output file."""

import argparse
import csv
import importlib.util
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
RULES = ["x:>= median - -3 * MAD or <= median + -3 * MAD"]


def find_outliers(source):
    """Use the collocated numerical implementation and the original saved criterion."""
    specification = importlib.util.spec_from_file_location('routliers_example_aggregate', HERE / 'aggregateData.py')
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    analysis = module.AggregateData()
    analysis.data = pd.read_csv(source, sep=r'\s+', encoding='utf-8')
    if list(analysis.data.columns) != ['x']:
        raise ValueError('The input must contain one numeric index column named x.')
    return analysis.filterData([], [], RULES)[['x']]


def main():
    """Resolve inputs independently of the working directory and protect saved references."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=HERE / 'anxietyData.dat')
    parser.add_argument('--output', type=Path, required=True, help='New CSV/text output; must not already exist.')
    arguments = parser.parse_args()
    source, output = arguments.input.resolve(), arguments.output.resolve()
    protected = {source, HERE / 'anxiety_outliers.txt', HERE / 'anxiety_outliers_psysummary.txt'}
    if output in protected or output.exists():
        parser.error('Choose a new output file; supplied inputs and reference results must not be overwritten.')
    if not source.is_file():
        parser.error(f'Input file not found: {source}')
    result = find_outliers(source)
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, sep='|', quoting=csv.QUOTE_NONNUMERIC, index=False, header=True)
    print(f'Exported {len(result)} outlier values to {output}')


if __name__ == '__main__':
    main()
