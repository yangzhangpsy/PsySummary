# Routliers MAD Comparison

This example compares the same MAD-based anxiety-index outliers in R/Routliers and PsySummary. The Attacks dataset is not an RT dataset; this is a numerical filtering check.

## Supplied Results

`anxietyData.dat` contains the index values. `anxiety_outliers.txt` contains the R/Routliers output, and `anxiety_outliers_psysummary.txt` contains the PsySummary output. Both list the same 25 values, including repeated observations, ranging from 3.5 to 4.0. `filters.psysum` supplies the saved GUI settings. Load the matching data before opening the setup.

## Optional Reproduction

Use a new output path so the supplied results remain unchanged. Both commands can be launched from any working directory when the script path is specified.

```sh
python "/path/to/Routliers, MAD/getOutliers.py" --output /path/to/new_python_outliers.csv
Rscript "/path/to/Routliers, MAD/getOutliers.R" --output /path/to/new_R_outliers.csv
```

The Python entry point defaults to its collocated `anxietyData.dat`; `--input` can specify another matching index file. It uses the collocated `aggregateData.py` and the original saved two-sided MAD criterion. Required Python packages are NumPy, pandas, SciPy, and mat73. The R entry point explicitly loads the Attacks dataset and calls `Routliers::outliers_mad`; install Routliers if it is not available. No interactive workspace preparation is required.

Compare the exported `x` values in order, preserving duplicates. The commands do not replace the supplied reference files or claim validation of additional datasets.
