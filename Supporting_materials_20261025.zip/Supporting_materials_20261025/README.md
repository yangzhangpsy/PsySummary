# PsySummary Supporting Materials

This package provides the data, saved settings, exported analysis modules, reference comparisons, and verification evidence supporting the manuscript's tutorial and validation.

## Contents

- `tutorial/`: six MAT inputs, renamed data, main/sensitivity setups, retained trials, summaries, CDF example, and an actual GUI-exported script bundle.
- `import_validation/`: ten accepted and two rejected cases per interface, complete loaded data, error messages, and exported replay bundles.
- `preprocessing_validation/`: five dataset-specific validation folders for Lin et al. (2020), Zhang et al. (2021), Hedge et al. (2018), Routliers, and Richards et al. (2021).
- `cognitive_reference/`: saved R distribution references, portable numerical checks, three simulated datasets, R/Python fits, comparison tables, and a fitting reproduction driver.
- `verification/`: a portable GUI-script replay check and a concise validation summary.
- `software_information/`: installation confirmation and the software README.

GUI source is maintained in the PsySummary Git repository and is not duplicated here. Each exported analysis script includes its matching numerical modules.

Interface illustrations are available in the manuscript and the repository's [figs directory](https://github.com/yangzhangpsy/PsySummary/tree/main/figs).

## Reproduce the supplied analyses

Python with NumPy, pandas, SciPy, Matplotlib, mat73, and h5py is required. The supplied replay and distribution-reference checks do not require Qt or a GUI source checkout. See `verification/README.md` and `cognitive_reference/README.md`.

Run the following from this package root:

```sh
python -B verification/verify_replays.py
python -B cognitive_reference/check_distribution_references.py
```

The first command copies the tutorial/import material to a temporary location, launches fresh Python processes without the GUI checkout on PYTHONPATH, and compares all values, types, columns, row order, filtered exports, and summaries. The second checks the exported numerical implementation against saved R/rtdists references and scientific invariants without rerunning the fitting benchmarks. The supplied reference data are not overwritten.

`tutorial/script_replay/` contains `analysis.py` plus seven actual export dependencies: `aggregateData.py`, `rtDist.py`, `cognitiveModels.py`, `cognitiveModelSpec.py`, `expression.py`, `dataPreparation.py`, and `poolingCDF.py`. Each import replay likewise retains its own matching export dependencies.

## Reading the evidence

`verification/TEST_RESULTS.md` summarizes the preprocessing comparisons, cognitive-model reference checks, and 21 GUI-exported script comparisons. Dataset-specific inputs, methods, and results are in the corresponding folders. Development regression tests and maintenance logs are not part of this research package.

The main tutorial retains 1,642 of 1,728 trials; changing only the upper RT bound from 1.5 to 1.0 s retains 1,636. The saved CDF example retains CDF <= omega, not the slow tail above it. Its 50-trial minimum is a numerical safeguard, not a reliability guarantee.

Installation/platform checks are author-confirmed. Numerical comparisons establish agreement for the supplied reference cases, not general parameter recovery.

The accompanying ZIP contains the files in this delivery folder.
