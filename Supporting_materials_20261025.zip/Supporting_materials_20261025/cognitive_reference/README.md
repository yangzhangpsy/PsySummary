# Cognitive-Model Reference Comparisons

The distribution checks and end-to-end fitting comparisons use rtdists 0.12-0. Saved results, shared inputs, and reproduction scripts are supplied below.

## Saved fitting comparison

For each model, the R and Python fits use the same 500 rtdists-generated observations, starting values, parameter bounds, and free parameters. R uses nlminb; the Python implementation uses constrained SLSQP.

| Model | R/rtdists NLL | PsySummary NLL |
| --- | ---: | ---: |
| Ratcliff diffusion | 290.4198394065 | 290.4198393401 |
| Linear ballistic accumulator | -0.7470428713 | -0.7470428708 |
| Racing diffusion | 63.4552460596 | 63.4552460598 |

The absolute NLL differences are below 7e-8 for Ratcliff and 5e-10 for LBA/RDM. Parameter differences are below 6e-6. The Ratcliff fit fixes relative zr to 0.5; low-level likelihood evaluation uses z = a * zr.

The complete results are `fit_comparison.csv`, `fit_comparison.md`, `rtdists_fits.csv`, and `psysummary_fits.csv`. The three `*_data.csv` files are the actual shared simulated inputs. These comparisons concern the specified cases, not general parameter recovery.

## Distribution-level references

`generate_rtdists_cognitive_reference.R` generates the independent PDF, defective-CDF, and conditional-quantile reference output. The saved output is `rtdists_distribution_reference.log`; its transcribed values are in `rtdists_reference.json`. `check_distribution_references.py` checks these values using the matching numerical modules exported in `../tutorial/script_replay/`.

From this package root, run:

```sh
python -B cognitive_reference/check_distribution_references.py
```

The check also covers probability mass, boundary coding, RT units, input validation, and the saved fitting-comparison tolerances. It does not require Qt, a GUI source checkout, or R, and does not rerun the fitting benchmarks or overwrite saved results.

The grid covers both response sides, multiple RTs, combined Ratcliff variability, positive LBA drift, and racing accumulators. LBA/RDM PDF differences are below 1e-9 and CDF/quantile differences below 1e-6 on the saved grid. Ratcliff combined-variability near-onset density error is below 2e-6; the reference conditional quantile is checked within 0.4 ms. These are reference-case tolerances.

LBA uses positive-truncated normal drift. The GUI does not expose every drift family or trial-wise parameter regression supported by more general modeling packages.

## Optional regeneration

From this package root, with R/rtdists and the Python numerical dependencies installed:

```sh
python -B cognitive_reference/validate_rtdists_fits.py --output-dir /path/to/new_fit_validation
```

Add `--r-library /path/to/R/library` or `--rscript /path/to/Rscript` when required. The driver imports the seven exported numerical modules in `tutorial/script_replay/`, without requiring a GUI checkout. Select a new or empty output directory outside cognitive_reference so the supplied reference results are preserved.

R and NumPy use different random streams. Within the saved benchmark both fitting implementations consume the same R-generated CSV data; sample-by-sample agreement between independently generated R and Python datasets is not claimed. The optimizers' iteration paths need not match.
