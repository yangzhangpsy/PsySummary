"""Check exported numerical modules against saved rtdists values and scientific invariants."""

import importlib
import json
import math
from pathlib import Path
import sys
import unittest
from copy import deepcopy

import numpy as np
import pandas as pd
from scipy.integrate import quad

REFERENCE_DIR = Path(__file__).resolve().parent
BUNDLE = REFERENCE_DIR.parent
ANALYSIS_MODULES = BUNDLE / 'tutorial' / 'script_replay'
if not (ANALYSIS_MODULES / 'cognitiveModels.py').is_file():
    raise FileNotFoundError('Keep this check with the supplied tutorial/script_replay modules.')
sys.path.insert(0, str(ANALYSIS_MODULES))


def module(name):
    """Load the numerical module supplied with the exported tutorial script."""
    return importlib.import_module(name)


def observations():
    """Provide the fixed response, accuracy, and grouping cases used by these checks."""
    return pd.DataFrame({'rt': np.linspace(.35, 1.15, 24),
                         'choice': np.tile([0, 1], 12),
                         'accuracy': np.tile([1, 1, 0, 1], 6),
                         'group': pd.Categorical(['A'] * 12 + ['B'] * 12,
                                                 categories=['A', 'B', 'unused'])})


def specification(model=None, **changes):
    """Use fixed parameters to check likelihood contracts without refitting benchmarks."""
    spec = module('cognitiveModelSpec')
    value = spec.make_model_specification(model or spec.RATCLIFF_MODEL, 'rt', 'choice', [0, 1],
                                         accuracy_variable='accuracy', minimum_rt=.35, **changes)
    for row in value['parameters']:
        row['mode'] = 'fixed'
    value['optimizer'].update(seed=20261025, starts=1, max_iterations=15)
    return value


class CognitiveNumericsCurrent(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.models = module('cognitiveModels')
        cls.specs = module('cognitiveModelSpec')
        cls.reference = json.loads((REFERENCE_DIR / 'rtdists_reference.json').read_text())

    def test_ddm_pdf_reference_baseline_and_combined_variability(self):
        for name in ('DDM baseline', 'DDM variability'):
            case = self.reference['cases'][name]
            for response, expected in case['responses'].items():
                with self.subTest(case=name, response=response):
                    np.testing.assert_allclose(self.models.diffusion_pdf(
                        self.reference['times'], response, **case['parameters']), expected['pdf'],
                        atol=2e-6, rtol=2e-7)

    def test_ddm_cdf_reference(self):
        for name in ('DDM baseline', 'DDM variability'):
            case = self.reference['cases'][name]
            for response, expected in case['responses'].items():
                self.assertAlmostEqual(self.models.diffusion_cdf(.8, response, **case['parameters']),
                                       expected['cdf'], delta=1e-5)

    def test_ddm_conditional_quantiles_reference(self):
        case = self.reference['cases']['DDM baseline']
        for response, expected in case['responses'].items():
            self.assertAlmostEqual(self.models.diffusion_quantile(
                .25, response, interval=(0, 10), scale_probability=True, **case['parameters']),
                expected['quantile'], delta=4e-4)

    def test_lba_and_racing_diffusion_pdf_cdf_quantiles_reference(self):
        for name, prefix in [('LBA', 'lba'), ('RDM', 'rdm')]:
            case = self.reference['cases'][name]
            for label, expected in case['responses'].items():
                response = int(label)
                with self.subTest(model=name, response=response):
                    np.testing.assert_allclose(getattr(self.models, prefix + '_pdf')(
                        self.reference['times'], response, **case['parameters']), expected['pdf'],
                        atol=1e-11, rtol=2e-9)
                    self.assertAlmostEqual(getattr(self.models, prefix + '_cdf')(
                        .8, response, **case['parameters']), expected['cdf'], delta=1e-6)
                    self.assertAlmostEqual(getattr(self.models, prefix + '_quantile')(
                        .25, response, interval=(0, 10), scale_probability=True, **case['parameters']),
                        expected['quantile'], delta=1e-6)

    def test_diffusion_total_mass_and_choice_probability(self):
        arguments = dict(a=1., v=1., t0=.2, z=.5, s=1.)
        masses = [quad(lambda value: self.models.diffusion_pdf(value, response, **arguments), .2, 8)[0]
                  for response in ('lower', 'upper')]
        self.assertAlmostEqual(sum(masses), 1., places=6)
        self.assertAlmostEqual(masses[1], 1 / (1 + math.exp(-1)), places=6)

    def test_relative_start_converts_to_absolute_without_changing_zr(self):
        parameters = {row['name']: row['value'] for row in specification()['parameters']}
        parameters.update(a=1.7, zr=.3)
        original = deepcopy(parameters)
        result = self.models._model_arguments(self.specs.RATCLIFF_MODEL, parameters, 2)
        self.assertAlmostEqual(result['z'], .51)
        self.assertEqual(parameters, original)

    def test_response_and_accuracy_coding_share_likelihood(self):
        source = observations()
        accuracy = specification(boundary_coding=self.specs.ACCURACY_CODING)
        response = specification(boundary_coding=self.specs.RESPONSE_CODING)
        for spec in (accuracy, response):
            for parameter in spec['parameters']:
                if parameter['name'] == 'zr':
                    parameter['value'] = .35
                if parameter['name'] == 'd':
                    parameter['value'] = .02
        left = self.models.fit_cognitive_model(source, accuracy)
        right = self.models.fit_cognitive_model(source, response)
        self.assertAlmostEqual(left['log_likelihood'], right['log_likelihood'], places=10)
        np.testing.assert_array_equal(left['parameters'], right['parameters'])

    def test_units_preserve_likelihood_and_source_data(self):
        seconds = observations()
        original = seconds.copy(deep=True)
        milliseconds = seconds.copy()
        milliseconds['rt'] *= 1000
        a = self.models.fit_cognitive_model(seconds, specification())
        b = self.models.fit_cognitive_model(milliseconds, specification(rt_unit='milliseconds'))
        self.assertAlmostEqual(a['log_likelihood'], b['log_likelihood'], places=10)
        pd.testing.assert_frame_equal(seconds, original)

    def test_invalid_response_and_accuracy_are_rejected(self):
        for variable, value in [('choice', 9), ('accuracy', 2), ('accuracy', np.nan)]:
            with self.subTest(variable=variable, value=value):
                frame = observations()
                frame.loc[0, variable] = value
                with self.assertRaises(ValueError):
                    self.models.fit_cognitive_model(frame, specification())

    def test_recorded_fitting_comparison_matches_reported_precision(self):
        frame = pd.read_csv(BUNDLE / 'cognitive_reference/fit_comparison.csv')
        self.assertEqual(set(frame['model']), {self.specs.RATCLIFF_MODEL, self.specs.LBA_MODEL, self.specs.RDM_MODEL})
        self.assertTrue(frame['rtdists_converged'].all() and frame['psysummary_converged'].all())
        self.assertTrue((frame['sample_size'] == 500).all())
        self.assertLess(frame['absolute_estimate_difference'].max(), 6e-6)
        self.assertLess(frame['absolute_nll_difference'].max(), 7e-8)


if __name__ == '__main__':
    unittest.main()
