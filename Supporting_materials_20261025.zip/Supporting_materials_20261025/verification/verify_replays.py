"""Replay the submitted scripts in a temporary relocated package and compare complete outputs."""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

BUNDLE = Path(__file__).resolve().parents[1]


def run():
    """Check every accepted import and both tutorial configurations without Qt or refitting models."""
    sys.path.insert(0, str(BUNDLE / 'tutorial/script_replay'))
    read_psydata = importlib.import_module('dataPreparation').read_psydata
    import pandas as pd
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    logs = BUNDLE / 'verification/logs/replay' / stamp
    logs.mkdir(parents=True)
    environment = dict(os.environ, MPLBACKEND='Agg', PYTHONDONTWRITEBYTECODE='1')
    environment.pop('PYTHONPATH', None)
    records = []
    with tempfile.TemporaryDirectory(prefix='psysummary-portable-') as directory:
        relocated = Path(directory) / 'package'
        relocated.mkdir()
        for name in ('tutorial', 'import_validation'):
            shutil.copytree(BUNDLE / name, relocated / name)
        scripts = [relocated / 'tutorial/script_replay/analysis.py']
        scripts.extend(sorted((relocated / 'import_validation').glob('replay_*/*/analysis.py')))
        for script in scripts:
            relative = script.relative_to(relocated)
            started = datetime.now(timezone.utc).isoformat()
            print(relative, flush=True)
            result = subprocess.run([sys.executable, '-B', str(script)], cwd=script.parent,
                                    env=environment, capture_output=True, text=True, timeout=90)
            name = '_'.join(relative.with_suffix('').parts) + '.log'
            log = logs / name
            log.write_text(f'Started UTC: {started}\nScript: {relative}\n\n'
                           f'{result.stdout}\n{result.stderr}\nReturn code: {result.returncode}\n',
                           encoding='utf-8')
            if result.returncode:
                raise RuntimeError(f'Replay failed: {relative}; see {log}')
            comparisons = []
            if relative.parts[0] == 'tutorial':
                expected = BUNDLE / 'tutorial'
                actual = relocated / 'tutorial'
                pd.testing.assert_frame_equal(read_psydata(actual / 'script_replay/replayed_source.psydata'),
                                              read_psydata(expected / 'script_replay/replayed_source.psydata'),
                                              check_exact=True)
                comparisons.append('All source cells, types, columns and row order')
                for label in ('main', 'sensitivity'):
                    pd.testing.assert_frame_equal(read_psydata(actual / (label + '_filtered.psydata')),
                                                  read_psydata(expected / (label + '_filtered.psydata')),
                                                  check_exact=True)
                    assert (actual / (label + '_filtered.csv')).read_bytes() == (
                        expected / (label + '_filtered.csv')).read_bytes()
                    pd.testing.assert_frame_equal(
                        pd.read_csv(actual / 'script_replay' / (label + '_replayed_means.csv'), index_col=[0, 1]),
                        pd.read_csv(expected / (label + '_means.csv'), index_col=[0, 1]),
                        check_exact=True)
                    comparisons.append(label + ': all retained cells, order, CSV bytes and summary values')
            else:
                variant = relative.parts[1].removeprefix('replay_')
                case = relative.parts[2]
                report = json.loads((BUNDLE / 'import_validation' / ('psysummary_gui_' + variant + '.json')).read_text())
                original_name = next(item['case'] for item in report['cases']
                                     if not item.get('rejected') and Path(item['case']).stem == case)
                expected = BUNDLE / 'import_validation' / ('imported_' + variant) / (original_name + '.psydata')
                pd.testing.assert_frame_equal(read_psydata(script.parent / 'replayed.psydata'),
                                              read_psydata(expected), check_exact=True)
                comparisons.append('All loaded cells, dtypes, columns and row order match saved GUI data')
            records.append({'script': str(relative), 'returncode': result.returncode,
                            'log': str(log.relative_to(BUNDLE)), 'checks': comparisons,
                            'script_sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
                            'finished_utc': datetime.now(timezone.utc).isoformat()})
    report = {'created_utc': datetime.now(timezone.utc).isoformat(), 'fresh_process': True,
              'temporary_relocated_package': True, 'gui_checkout_on_pythonpath': False,
              'all_passed': True,
              'scripts': len(records), 'records': records}
    output = BUNDLE / 'verification/reports/portable_replays.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(report, indent=2), encoding='utf-8')
    print('PASS:', len(records), 'portable scripts')


if __name__ == '__main__':
    run()
