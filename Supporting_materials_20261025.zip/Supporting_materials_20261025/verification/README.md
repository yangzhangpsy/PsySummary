# Validation and Script Replay

`TEST_RESULTS.md` summarizes the validation cases, comparisons, and verification environment. This folder contains only the summary and the portable replay entry point.

## Reproduce GUI-script comparisons

From this package root:

```sh
python -B verification/verify_replays.py
```

The check runs twenty accepted-file scripts and the tutorial script in fresh Python processes from a temporary relocated package. It compares every loaded cell, dtype, column, and row position with the saved GUI data. The tutorial comparison also checks all retained cells, row order, exact filtered CSV bytes, and participant-by-SOA means for the main and sensitivity configurations. Supplied inputs and reference outputs are not overwritten.

Running the check creates `logs/replay/` and `reports/portable_replays.json` with the new execution results; these are generated outputs, not required inputs. It does not overwrite `TEST_RESULTS.md`.

Python with NumPy, pandas, SciPy, Matplotlib, mat73, and h5py is required. Qt, a GUI source checkout, and R are not required for script replay.

## Other validation materials

- `../preprocessing_validation/`: the five dataset-specific preprocessing comparisons.
- `../cognitive_reference/`: saved R/rtdists distribution references, portable numerical checks, shared simulated data, and fitting comparisons.
- `../import_validation/`: import examples, saved GUI data, outcomes, and matching exported scripts.

R/rtdists is needed only to regenerate independent references or fitting benchmarks. See `../cognitive_reference/README.md`.
