# Validation Summary

## Preprocessing comparisons

`../preprocessing_validation/` supplies the data, methods, and results for five comparisons: Lin et al. (2020), Zhang et al. (2021), Hedge et al. (2018), the Routliers Attacks dataset, and Richards et al. (2021). The Routliers comparison is a numerical filtering benchmark rather than an RT-specific validation. The Richards comparison reproduces the reported group-specific exclusions and participant-by-position median summaries at the reported precision.

## Cognitive-model references

`../cognitive_reference/` contains the R/rtdists 0.12-0 distribution output, transcribed reference values, numerical checks, shared simulated data, and fitting comparisons. The distribution checks cover densities, response-specific cumulative probabilities, and conditional quantiles for the Ratcliff diffusion, linear ballistic accumulator, and racing diffusion models.

All ten checks in `../cognitive_reference/check_distribution_references.py` passed on October 25, 2026, using the supplied exported numerical modules. These checks do not rerun the fitting benchmarks.

The saved fitting benchmarks use one shared dataset of 500 observations per model, with matching starting values, bounds, and free parameters. Absolute negative log-likelihood differences are below 7e-8 for Ratcliff and 5e-10 for LBA/RDM; parameter differences are below 6e-6. These comparisons concern the specified cases, not general parameter recovery. Detailed values and reproduction instructions are in `../cognitive_reference/README.md`.

## GUI export and script replay

All 21 supplied scripts passed complete replay comparisons on October 25, 2026: ten accepted import examples from each interface and one integrated tutorial script. Each script includes its seven matching numerical modules and runs in a fresh process from a temporary relocated package without a GUI checkout on PYTHONPATH.

| Comparison | Scope |
| --- | --- |
| Imported data | Every loaded cell, dtype, column, and row position matches the saved GUI data. |
| Tutorial source | All imported and renamed values, types, columns, and row order match the supplied source. |
| Main and sensitivity filters | All retained cells and row order match; exported CSV bytes are identical. |
| Tutorial summaries | Participant-by-SOA mean RTs match the saved summaries for both configurations. |

The main configuration retains 1,642 of 1,728 trials. Changing only the upper RT bound from 1.5 to 1.0 s retains 1,636. The paired results illustrate sensitivity to the cutoff; they do not establish an optimal rule. Import inputs, outcomes, saved GUI data, and replay bundles are in `../import_validation/`; tutorial inputs, settings, and results are in `../tutorial/`.

Run `python -B verification/verify_replays.py` from the package root to repeat the comparisons without overwriting the supplied reference outputs.

## Verification environment

The recorded Python verification environment was macOS with Python 3.13.2, NumPy 2.4.6, pandas 3.0.6, SciPy 1.18.1, Matplotlib 3.11.2, mat73 0.65, and h5py 3.16.0. These describe the recorded environment, not minimum requirements or exhaustive platform coverage. Qt and R are not required to replay the supplied scripts or check the saved distribution references.
