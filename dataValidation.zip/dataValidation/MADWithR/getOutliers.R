data(Attacks)
anxiety <- rowMeans(Attacks[,c("hsc1","hsc2","hsc3","hsc4","hsc5","hsc6","hsc7","hsc8","hsc9","hsc10")])
res1 <- outliers_mad(x = anxiety)
res1$outliers

write.csv(res1$outliers,"~/Downloads/anxiety_outliers.txt", row.names = FALSE)

