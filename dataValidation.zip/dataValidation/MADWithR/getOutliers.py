from .aggregateData import AggregateData
aggData = AggregateData()
fileList = ["/Users/Zy/netWorking/2024 PsySummary/dataValidation/MADWithR/anxietyData.dat"]
aggData.readDatFiles(fileList, True,'utf-8', '\s')
rowVariables = []
colVariables = []
ruleList = ["x:>= median - -3 * MAD or <= median + -3 * MAD"]
targetVariables = ["x@Count"]
filteredDataFrame = aggData.filterData(rowVariables, colVariables, ruleList)
filteredDataFrame.to_csv('anxiety_outliers_psysummary.txt', sep='|', quoting=csv.QUOTE_NONNUMERIC, index=False, header=True) 