我们做了三种不同的validation:


1)我们利用Lin等（2020, cognition）的行为数据，采用完全类相同的数据筛选逻辑和步骤（先去除反应错误的试次，后针对对每个实验条件去除反应时小于100 ms和大于平均数2.5倍标准差的试次），利用PsySummary图形界面进行了数据分析，在分析中我们尝试了将MAT格式的数据导出为txt再导入PsySummary和直接导入MAT格式数据到PsySummary两种数据导入方法。分析结果如附件（lin et al., 2020 Data Validation.xlsx）所示，无论是那种数据导入方法，在PsySummary界面中对数据进行筛选和汇总后的结果和Lin等研究中的行为结果完全一致。 数据和汇总比较excel文件在nSDs目录下。


2）我们利用Hedge等（2018, BRM）研究1中Flanker任务的session1的行为数据，采用完全相同的数据筛选逻辑和步骤，在PsySummay图形界面进行了数据分析，分析结果如附件(Hedge et al., 2018 Data Validation.xlsx)所示，几乎和原文中的汇总数据完全一样，仅一些结果部分有不超过0.001的误差（可能原因在于文章汇报中的数据保留精度问题）。




3） 我们直接利用R工具包Routliers（https://github.com/mdelacre/Routliers）进行了验证，我们利用其工具包自带的Attacks数据，构建的anxiety指数（参见Leys等2019），并同时利用Routiers工具包（代码参见附件中的getOutliers.R）和PsySummay对其中的极端值进行了筛选，结果完全一致（anxiety_outliers.txt vs. anxiety_outilers_psysummary.txt）。 

PsySummary操作如下： 1）File -> load data 加载 anxietyData.dat 文件，然后在点击 load filter 按钮加载filtes.psysum文件读入定义好的filters，并点击Run按钮得到汇总结果。最后在file菜单下点击 Save Filtered Data 输出筛选出来的极端值数据。具体的分析代码也可以参见附件中的getOutliers.py文件。




参考文献：

Leys, C., Delacre, M., Mora, Y. L., Lakens, D., &amp; Ley, C. (2019). How to Classify, Detect, and Manage Univariate and Multivariate Outliers, With Emphasis on Pre-Registration. International Review of Social Psychology,32(1), 5. https://doi.org/10.5334/irsp.289

Hedge, C., Powell, G. & Sumner, P. The reliability paradox: Why robust cognitive tasks do not produce reliable individual differences. Behav Res 50, 1166–1186 (2018). https://doi.org/10.3758/s13428-017-0935-1

Lin, Z.C., Miao,C.G.,  & Zhang, Y. (2020). Human electrophysiology reveals delayed but enhanced selection in inhibition of return. Cognition. 205: 104462.